module.exports = function (fnum, snum) {
  return fnum * snum;
};
