
Problem Statement - Calculator app

Standard Calculator is a simple Calculator use by common person we can do only some mathematical function like addition, division, subtraction and multiplication. Standard Calculator has limited function beyond this Scientific Calculators have numerous number of function.

User can use standard calculator at their office, at their shop, at their business to perform simple calculation like:

Adding the Number
Subtracting the Number
Multiplying the Number
Dividing the Number

User can automate their daily calculation tasks by using Standard Calculator.



Instructions

Download and unzip the boilerplate code.
Run the command npm install to install the dependencies.
Open the boilerplate code in VSCode to develop the solution.
Write the code in the .js files present in calculator/math folder
Run the test scripts available under test folder by giving npm run test command in the terminal to test locally.
Refactor the solution to ensure all test cases are passing.
Zip the solution code with the name same as assignment name.
Upload the zipped solution for submission.